//
//  IvIndex.swift
//  nRFMeshProvision
//
//  Created by Aleksander Nowakowski on 15/05/2019.
//

import Foundation

internal struct IvIndex {
    var index: UInt32 = 0
    var updateActive: Bool = false
}
